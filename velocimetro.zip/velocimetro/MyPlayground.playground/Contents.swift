//Velocimetro John Veronelli


import UIKit

enum Velocidades : Int{
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120;
    
    init (velocidadInicial: Velocidades){
        self = velocidadInicial
    }
}

class  Auto {
    var velocidad : Velocidades
    var numeroVel: Int
    
    init(){
        self.velocidad = .Apagado
        numeroVel = self.velocidad.rawValue
    }
    
    func cambioDeVelocidad( ) -> ( velActual : Int, salida: String){
        let indicador : String
        numeroVel = self.velocidad.rawValue
        
        switch self.velocidad{
        case .Apagado:
            self.velocidad = .VelocidadBaja
            indicador = "Apagado"
        case .VelocidadBaja:
            self.velocidad = .VelocidadMedia
            indicador = "Velocidad Baja"
        case .VelocidadMedia:
            self.velocidad = .VelocidadAlta
            indicador = "Velocidad Media"
        case .VelocidadAlta:
            self.velocidad = .VelocidadMedia
            indicador = "Velocidad Alta"
        }
        
        return (velActual: numeroVel, salida: indicador)
    }
}

var auto = Auto()
var valoresVel : (velActual : Int, salida : String )

for var i in 1...20 {
    
    valoresVel = auto.cambioDeVelocidad()
    print("\(valoresVel.velActual), \(valoresVel.salida)")
}